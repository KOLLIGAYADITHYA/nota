import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  BookOpen,
  CalendarClock,
  LayoutDashboard,
  LibraryBig,
  LineChart,
  Loader2,
  NotebookPen,
  ScrollText,
  ShieldCheck,
} from "lucide-react";
import { useEffect, type ReactNode } from "react";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/library", label: "Library", icon: LibraryBig },
  { to: "/planner", label: "Study planner", icon: CalendarClock },
  { to: "/revise", label: "Revision sheets", icon: ScrollText },
  { to: "/progress", label: "Progress", icon: LineChart },
  { to: "/plan", label: "Project plan", icon: NotebookPen },
] as const;


const ADMIN_NAV = { to: "/admin", label: "Admin", icon: ShieldCheck } as const;

export function AppShell({ children, requireAuth = true }: { children: ReactNode; requireAuth?: boolean }) {
  const { user, loading, signOut } = useAuth();
  const { isAdmin } = useIsAdmin();
  const navigate = useNavigate();

  useEffect(() => {
    if (requireAuth && !loading && !user) navigate({ to: "/auth" });
  }, [requireAuth, loading, user, navigate]);

  const items = isAdmin ? [...NAV, ADMIN_NAV] : NAV;


  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-4">
          <Link to="/" className="flex items-center gap-2">
            <BookOpen className="size-5 text-primary" />
            <span className="font-display text-2xl leading-none">Nota</span>
          </Link>
          <nav className="hidden items-center gap-1 sm:flex">
            {items.map(({ to, label, icon: Icon }) => (
              <Link
                key={to}
                to={to}
                className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                activeProps={{ className: "bg-secondary text-foreground" }}
              >
                <Icon className="size-4" />
                {label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            {user ? (
              <>
                <span className="hidden text-sm text-muted-foreground md:inline">{user.email}</span>
                <Button variant="outline" size="sm" onClick={() => signOut()}>
                  Sign out
                </Button>
              </>
            ) : (
              <Button size="sm" asChild>
                <Link to="/auth">Sign in</Link>
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {requireAuth && loading ? (
          <div className="flex h-64 items-center justify-center text-muted-foreground">
            <Loader2 className="size-5 animate-spin" />
          </div>
        ) : requireAuth && !user ? null : (
          children
        )}
      </main>
    </div>
  );
}
