import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { AGENTS, type AgentId } from "@/lib/agents";
import { askDocument, generateQuizBatch, listDocumentSections, startQuiz } from "@/lib/study.functions";
import { MicRecorder, playBase64Audio, stopAudio } from "@/lib/voice";
import { speakText, transcribeAudio } from "@/lib/voice.functions";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { ExternalLink, Globe, Loader2, Mic, Sparkles, Square, Volume2 } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/doc/$docId")({
  head: () => ({
    meta: [
      { title: "Study this document — Nota" },
      { name: "description", content: "Ask questions about your notes and get answers with page citations." },
      { property: "og:title", content: "Study this document — Nota" },
      { property: "og:description", content: "Cited answers and quizzes from your own notes." },
    ],
  }),
  component: DocPage,
});

type Citation = {
  page: number;
  snippet: string;
  similarity: number;
  url?: string | null;
  title?: string | null;
};
type QuizQuestion = {
  id: string;
  question: string;
  options: string[];
  correct_index: number;
  explanation: string | null;
  topic: string | null;
  page: number | null;
};

function DocPage() {
  return (
    <AppShell>
      <DocContent />
    </AppShell>
  );
}

function DocContent() {
  const { docId } = Route.useParams();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const ask = useServerFn(askDocument);
  const beginQuiz = useServerFn(startQuiz);
  const runBatch = useServerFn(generateQuizBatch);
  const fetchSections = useServerFn(listDocumentSections);
  const transcribe = useServerFn(transcribeAudio);
  const speak = useServerFn(speakText);

  const [question, setQuestion] = useState("");
  const [agent, setAgent] = useState<AgentId>("tutor");
  const [asking, setAsking] = useState(false);
  const [citations, setCitations] = useState<Citation[]>([]);
  const [quizBusy, setQuizBusy] = useState(false);
  const [quizCount, setQuizCount] = useState(20);
  const [quiz, setQuiz] = useState<QuizQuestion[] | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [quizId, setQuizId] = useState<string | null>(null);
  const [selectedSections, setSelectedSections] = useState<number[]>([]);
  const [pageFrom, setPageFrom] = useState("");
  const [pageTo, setPageTo] = useState("");
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [sectionsUsed, setSectionsUsed] = useState<
    { index: number; title: string; startPage: number; endPage: number }[]
  >([]);

  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const [handsFree, setHandsFree] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const recorder = useRef<MicRecorder | null>(null);

  const { data: doc } = useQuery({
    queryKey: ["document", docId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("id, title, page_count, chunk_count")
        .eq("id", docId)
        .maybeSingle();
      if (error) throw new Error(error.message);
      return data;
    },
  });

  const { data: messages } = useQuery({
    queryKey: ["messages", docId],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("id, role, content, citations, created_at")
        .eq("document_id", docId)
        .order("created_at", { ascending: true });
      if (error) throw new Error(error.message);
      return data;
    },
  });

  const { data: sections } = useQuery({
    queryKey: ["sections", docId],
    enabled: !!user,
    queryFn: () => fetchSections({ data: { documentId: docId } }),
  });



  async function readAloud(text: string) {
    try {
      setSpeaking(true);
      const { audioBase64, mimeType } = await speak({
        data: { text: text.replace(/[*#`>]/g, "").slice(0, 3800) },
      });
      const audio = playBase64Audio(audioBase64, mimeType);
      audio.onended = () => setSpeaking(false);
    } catch (err) {
      setSpeaking(false);
      toast.error(err instanceof Error ? err.message : "Could not read that aloud");
    }
  }

  async function submitQuestion(text: string) {
    if (!text.trim()) return;
    setAsking(true);
    try {
      const result = await ask({ data: { documentId: docId, question: text.trim(), agent } });
      setCitations(result.citations as Citation[]);
      setQuestion("");
      queryClient.invalidateQueries({ queryKey: ["messages", docId] });
      if (handsFree) await readAloud(result.answer);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not answer that");
    } finally {
      setAsking(false);
    }
  }

  async function handleAsk(e: React.FormEvent) {
    e.preventDefault();
    await submitQuestion(question);
  }

  async function toggleMic() {
    if (recording) {
      setRecording(false);
      setTranscribing(true);
      try {
        const b64 = await recorder.current?.stop();
        recorder.current = null;
        if (!b64) {
          toast.error("That recording was empty — try again.");
          return;
        }
        const { text } = await transcribe({ data: { audioBase64: b64, mimeType: "audio/wav" } });
        if (!text) {
          toast.error("Could not hear anything in that clip.");
          return;
        }
        setQuestion(text);
        await submitQuestion(text);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Voice input failed");
      } finally {
        setTranscribing(false);
      }
      return;
    }

    try {
      stopAudio();
      setSpeaking(false);
      const rec = new MicRecorder();
      await rec.start();
      recorder.current = rec;
      setRecording(true);
    } catch {
      toast.error("Microphone access is needed for voice input.");
    }
  }

  async function handleQuiz(focusWeakTopics: boolean) {
    setQuizBusy(true);
    setQuiz([]);
    setAnswers({});
    setSectionsUsed([]);
    setProgress({ done: 0, total: quizCount });
    try {
      const scope = {
        documentId: docId,
        count: quizCount,
        focusWeakTopics,
        sectionIndices: selectedSections,
        pageFrom: pageFrom ? Number(pageFrom) : null,
        pageTo: pageTo ? Number(pageTo) : null,
      };
      const plan = await beginQuiz({ data: scope });
      setQuizId(plan.quizId);
      setSectionsUsed(plan.sectionsUsed);

      await Promise.all(
        plan.batches.map(async (b) => {
          const { questions } = await runBatch({
            data: {
              ...scope,
              quizId: plan.quizId,
              batchIndex: b.batchIndex,
              batchCount: b.count,
              totalBatches: plan.batches.length,
            },
          });
          const incoming = (questions as QuizQuestion[]).map((q) => ({
            ...q,
            options: q.options as unknown as string[],
          }));
          setQuiz((prev) =>
            [...(prev ?? []), ...incoming].sort(
              (x, y) => ((x as any).position ?? 0) - ((y as any).position ?? 0),
            ),
          );
          setProgress((p) => (p ? { ...p, done: p.done + incoming.length } : p));
        }),
      );
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not build a quiz");
    } finally {
      setQuizBusy(false);
      setProgress(null);
    }
  }

  async function answerQuestion(q: QuizQuestion, index: number) {
    if (answers[q.id] !== undefined || !quizId) return;
    setAnswers((prev) => ({ ...prev, [q.id]: index }));
    await supabase.from("quiz_attempts").insert({
      quiz_id: quizId,
      question_id: q.id,
      selected_index: index,
      is_correct: index === q.correct_index,
      topic: q.topic,
    });
  }

  const answered = quiz ? quiz.filter((q) => answers[q.id] !== undefined) : [];
  const score = quiz ? answered.filter((q) => answers[q.id] === q.correct_index).length : 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl">{doc?.title ?? "Document"}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          {doc ? `${doc.page_count} pages · ${doc.chunk_count} indexed sections` : "Loading…"}
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
        <div className="paper flex flex-col p-5">
          <div className="mb-4 flex flex-wrap items-center gap-2">
            {AGENTS.map((a) => (
              <button
                key={a.id}
                type="button"
                onClick={() => setAgent(a.id)}
                title={a.blurb}
                className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs transition-colors ${
                  agent === a.id
                    ? "border-primary bg-primary/10 text-foreground"
                    : "border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {a.usesWeb && <Globe className="size-3" />}
                {a.name}
              </button>
            ))}
            <button
              type="button"
              onClick={() => setHandsFree((v) => !v)}
              className={`ml-auto flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs transition-colors ${
                handsFree ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground"
              }`}
            >
              <Volume2 className="size-3" />
              Hands-free {handsFree ? "on" : "off"}
            </button>
          </div>

          <p className="mb-4 text-xs text-muted-foreground">
            {AGENTS.find((a) => a.id === agent)?.blurb}
          </p>

          <div className="space-y-4">
            {(messages ?? []).length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Ask anything about these notes — by typing or by voice. Every answer cites where it came from.
              </p>
            ) : (
              messages!.map((m) => (
                <div
                  key={m.id}
                  className={
                    m.role === "user"
                      ? "ml-auto max-w-[85%] rounded-lg bg-secondary px-3 py-2 text-sm"
                      : "max-w-[95%] whitespace-pre-wrap text-sm leading-relaxed"
                  }
                >
                  {m.content}
                  {m.role === "assistant" && (
                    <button
                      type="button"
                      onClick={() => readAloud(m.content)}
                      className="mt-1 flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground"
                    >
                      <Volume2 className="size-3" /> Listen
                    </button>
                  )}
                </div>
              ))
            )}
          </div>

          {speaking && (
            <button
              type="button"
              onClick={() => {
                stopAudio();
                setSpeaking(false);
              }}
              className="mt-4 flex items-center gap-1.5 self-start text-xs text-muted-foreground hover:text-foreground"
            >
              <Square className="size-3" /> Stop audio
            </button>
          )}

          <form onSubmit={handleAsk} className="mt-6 flex gap-2">
            <Button
              type="button"
              variant={recording ? "destructive" : "outline"}
              size="icon"
              onClick={toggleMic}
              disabled={transcribing || asking}
              aria-label={recording ? "Stop recording" : "Ask by voice"}
            >
              {transcribing ? (
                <Loader2 className="size-4 animate-spin" />
              ) : recording ? (
                <Square className="size-4" />
              ) : (
                <Mic className="size-4" />
              )}
            </Button>
            <Input
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder={
                recording ? "Listening… tap the square when you're done" : "Ask, or tap the mic to speak"
              }
            />
            <Button type="submit" disabled={asking || recording}>
              {asking ? <Loader2 className="size-4 animate-spin" /> : "Ask"}
            </Button>
          </form>

          <div className="mt-3 flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                const prompt =
                  question.trim() ||
                  `Explain this topic clearly for exam revision: ${doc?.title ?? "my study notes"}`;
                window.open(`https://chatgpt.com/?q=${encodeURIComponent(prompt)}`, "_blank", "noreferrer");
              }}
              className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1 text-xs text-muted-foreground transition-colors hover:text-foreground"
            >
              <ExternalLink className="size-3" />
              Search from online in ChatGPT
            </button>
            <span className="text-xs text-muted-foreground">
              opens ChatGPT in a new tab with your question ready
            </span>
          </div>
        </div>

        <div className="space-y-6">
          <div className="paper p-5">
            <h2 className="font-display text-2xl">Sources</h2>
            {citations.length === 0 ? (
              <p className="mt-2 text-sm text-muted-foreground">
                Citations from your latest answer appear here.
              </p>
            ) : (
              <ul className="mt-3 space-y-3">
                {citations.map((c, i) => (
                  <li key={i} className="text-sm">
                    {c.url ? (
                      <a
                        href={c.url}
                        target="_blank"
                        rel="noreferrer"
                        className="font-medium underline underline-offset-2"
                      >
                        {c.title ?? c.url}
                      </a>
                    ) : (
                      <span className="font-medium">Page {c.page}</span>
                    )}
                    <p className="mt-1 text-muted-foreground">{c.snippet}…</p>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="paper p-5">
            <h2 className="font-display text-2xl">Quiz yourself</h2>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {[10, 20, 30].map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => setQuizCount(n)}
                  className={`rounded-full border px-3 py-1 text-xs ${
                    quizCount === n ? "border-primary bg-primary/10" : "border-border text-muted-foreground"
                  }`}
                >
                  {n} questions
                </button>
              ))}
            </div>

            <div className="mt-4">
              <p className="text-xs font-medium">Which parts of your notes?</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                <button
                  type="button"
                  onClick={() => setSelectedSections([])}
                  className={`rounded-full border px-2.5 py-1 text-xs ${
                    selectedSections.length === 0
                      ? "border-primary bg-primary/10"
                      : "border-border text-muted-foreground"
                  }`}
                >
                  Whole document
                </button>
                {(sections ?? []).map((s) => (
                  <button
                    key={s.index}
                    type="button"
                    onClick={() =>
                      setSelectedSections((prev) =>
                        prev.includes(s.index) ? prev.filter((i) => i !== s.index) : [...prev, s.index],
                      )
                    }
                    title={`Pages ${s.startPage}–${s.endPage}`}
                    className={`rounded-full border px-2.5 py-1 text-xs ${
                      selectedSections.includes(s.index)
                        ? "border-primary bg-primary/10"
                        : "border-border text-muted-foreground"
                    }`}
                  >
                    {s.title} · p{s.startPage}–{s.endPage}
                  </button>
                ))}
              </div>
              <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                <span>Pages</span>
                <Input
                  value={pageFrom}
                  onChange={(e) => setPageFrom(e.target.value.replace(/\D/g, ""))}
                  placeholder="from"
                  className="h-8 w-20"
                  inputMode="numeric"
                />
                <span>to</span>
                <Input
                  value={pageTo}
                  onChange={(e) => setPageTo(e.target.value.replace(/\D/g, ""))}
                  placeholder="to"
                  className="h-8 w-20"
                  inputMode="numeric"
                />
              </div>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              <Button size="sm" onClick={() => handleQuiz(false)} disabled={quizBusy}>
                {quizBusy ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Sparkles className="mr-2 size-4" />}
                New quiz
              </Button>
              <Button size="sm" variant="outline" onClick={() => handleQuiz(true)} disabled={quizBusy}>
                Target weak topics
              </Button>
            </div>

            {progress && (
              <div className="mt-3">
                <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${Math.round((progress.done / progress.total) * 100)}%` }}
                  />
                </div>
                <p className="mt-1.5 text-xs text-muted-foreground">
                  {progress.done} of {progress.total} questions ready — they appear as they are written.
                </p>
              </div>
            )}

            {sectionsUsed.length > 0 && (
              <p className="mt-3 text-xs text-muted-foreground">
                Built from: {sectionsUsed.map((s) => `${s.title} (p${s.startPage}–${s.endPage})`).join(" · ")}
              </p>
            )}


            {quiz && (
              <>
                <p className="mt-4 text-sm text-muted-foreground">
                  {answered.length}/{quiz.length} answered · {score} correct
                </p>
                <div className="mt-3 space-y-5">
                  {quiz.map((q, qi) => {
                    const chosen = answers[q.id];
                    return (
                      <div key={q.id} className="space-y-2">
                        <p className="text-sm font-medium">
                          {qi + 1}. {q.question}
                        </p>
                        <div className="space-y-1.5">
                          {q.options.map((opt, i) => {
                            const isAnswered = chosen !== undefined;
                            const isCorrect = i === q.correct_index;
                            const state = !isAnswered
                              ? "border-border hover:border-primary"
                              : isCorrect
                                ? "border-primary bg-primary/10"
                                : i === chosen
                                  ? "border-destructive bg-destructive/10"
                                  : "border-border opacity-60";
                            return (
                              <button
                                key={i}
                                type="button"
                                disabled={isAnswered}
                                onClick={() => answerQuestion(q, i)}
                                className={`w-full rounded-md border px-3 py-2 text-left text-sm transition-colors ${state}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                        {chosen !== undefined && q.explanation && (
                          <p className="text-xs text-muted-foreground">
                            {q.explanation}
                            {q.page ? ` (page ${q.page})` : ""}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
