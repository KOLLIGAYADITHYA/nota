import { AppShell } from "@/components/AppShell";
import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/plan")({
  head: () => ({
    meta: [
      { title: "Project plan — Nota" },
      { name: "description", content: "The problem, the wedge, the MVP scope and the business case behind Nota." },
      { property: "og:title", content: "Project plan — Nota" },
      { property: "og:description", content: "How Nota is scoped, built and evaluated." },
    ],
  }),
  component: PlanPage,
});

const SECTIONS = [
  {
    title: "Problem",
    body: "Students drown in their own material. Generic AI chatbots answer from the open web, so answers drift from the syllabus a student is actually examined on, and there is no way to verify a claim against the source page.",
  },
  {
    title: "Wedge",
    body: "Nota answers strictly from documents the student uploads, with page-level citations on every response. If the notes don't cover it, Nota says so instead of inventing an answer.",
  },
  {
    title: "MVP scope",
    body: "Upload a PDF, index it into searchable sections, chat with cited answers, and generate exam-style quizzes from the same material. Quiz results feed a topic mastery view that can target weak areas.",
  },
  {
    title: "Deliberately cut for v1",
    body: "Voice interaction, multi-language, multi-agent orchestration and open-web fallback. Each adds surface area without strengthening the core promise of grounded, verifiable study help.",
  },
  {
    title: "Business feasibility",
    body: "Cost per student is dominated by embeddings at upload time and short grounded completions at question time — both cheap and bounded per document. A freemium tier with a document cap converts on exam-season urgency, and campus/department licensing is the natural second motion.",
  },
  {
    title: "How success is measured",
    body: "Percentage of answers a student rates as grounded, quiz accuracy improvement over repeated attempts on the same topic, and weekly return rate during the four weeks before an exam.",
  },
];

function PlanPage() {
  return (
    <AppShell requireAuth={false}>
      <div className="space-y-8">
        <div>
          <h1 className="font-display text-4xl">Project plan</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            From problem identification to business feasibility — the reasoning behind what got built.
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {SECTIONS.map((s) => (
            <section key={s.title} className="paper p-6">
              <h2 className="font-display text-2xl">{s.title}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </section>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
