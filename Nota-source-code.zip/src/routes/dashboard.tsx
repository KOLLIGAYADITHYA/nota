import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { AGENTS } from "@/lib/agents";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { FileText, Loader2, MessageSquare, Target, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Nota" },
      {
        name: "description",
        content: "Your study dashboard: documents, quiz accuracy, weak topics and AI study agents.",
      },
      { property: "og:title", content: "Dashboard — Nota" },
      { property: "og:description", content: "Everything you are studying, in one view." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  return (
    <AppShell>
      <DashboardContent />
    </AppShell>
  );
}

function DashboardContent() {
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ["dashboard", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const [docs, attempts, messages] = await Promise.all([
        supabase
          .from("documents")
          .select("id, title, page_count, chunk_count, created_at")
          .order("created_at", { ascending: false })
          .limit(5),
        supabase.from("quiz_attempts").select("topic, is_correct").limit(1000),
        supabase.from("messages").select("id").limit(1000),
      ]);
      if (docs.error) throw new Error(docs.error.message);
      return {
        docs: docs.data ?? [],
        attempts: attempts.data ?? [],
        messageCount: (messages.data ?? []).length,
      };
    },
  });

  if (isLoading || !data) {
    return (
      <div className="flex h-64 items-center justify-center text-muted-foreground">
        <Loader2 className="size-5 animate-spin" />
      </div>
    );
  }

  const total = data.attempts.length;
  const correct = data.attempts.filter((a) => a.is_correct).length;
  const accuracy = total ? Math.round((correct / total) * 100) : 0;

  const tally = new Map<string, { wrong: number; total: number }>();
  for (const a of data.attempts) {
    const key = a.topic ?? "Uncategorised";
    const row = tally.get(key) ?? { wrong: 0, total: 0 };
    row.total += 1;
    if (!a.is_correct) row.wrong += 1;
    tally.set(key, row);
  }
  const weak = [...tally.entries()]
    .filter(([, v]) => v.wrong > 0)
    .sort((a, b) => b[1].wrong / b[1].total - a[1].wrong / a[1].total)
    .slice(0, 5);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl">Dashboard</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Your material, your accuracy and the agents that can help you today.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={FileText} label="Documents" value={String(data.docs.length)} />
        <Stat icon={MessageSquare} label="Tutor messages" value={String(data.messageCount)} />
        <Stat icon={Target} label="Questions answered" value={String(total)} />
        <Stat icon={TrendingUp} label="Accuracy" value={`${accuracy}%`} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="paper p-5">
          <h2 className="font-display text-2xl">Recent documents</h2>
          {data.docs.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">
              Nothing uploaded yet.{" "}
              <Link to="/library" className="underline">
                Add your first PDF
              </Link>
              .
            </p>
          ) : (
            <ul className="mt-3 divide-y divide-border">
              {data.docs.map((d) => (
                <li key={d.id} className="flex items-center gap-3 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{d.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {d.page_count} pages · {d.chunk_count} sections
                    </p>
                  </div>
                  <Button size="sm" variant="outline" asChild>
                    <Link to="/doc/$docId" params={{ docId: d.id }}>
                      Study
                    </Link>
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="paper p-5">
          <h2 className="font-display text-2xl">Weak topics</h2>
          {weak.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">
              No weak spots yet — take a quiz and this fills in.
            </p>
          ) : (
            <ul className="mt-3 space-y-3">
              {weak.map(([topic, row]) => (
                <li key={topic} className="flex items-center gap-3 text-sm">
                  <span className="flex-1">{topic}</span>
                  <div className="h-2 w-32 overflow-hidden rounded-full bg-secondary">
                    <div
                      className="h-full bg-destructive"
                      style={{ width: `${Math.round((row.wrong / row.total) * 100)}%` }}
                    />
                  </div>
                  <span className="w-14 text-right text-muted-foreground">
                    {row.wrong}/{row.total}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="paper p-5">
        <h2 className="font-display text-2xl">Your AI study agents</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Pick an agent inside any document — each one answers in a different way.
        </p>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {AGENTS.map((a) => (
            <div key={a.id} className="rounded-lg border border-border p-4">
              <p className="text-sm font-medium">
                {a.name}
                {a.usesWeb && (
                  <span className="ml-2 rounded bg-secondary px-1.5 py-0.5 text-xs text-muted-foreground">
                    web search
                  </span>
                )}
              </p>
              <p className="mt-1 text-sm text-muted-foreground">{a.blurb}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof FileText;
  label: string;
  value: string;
}) {
  return (
    <div className="paper p-5">
      <Icon className="size-4 text-primary" />
      <div className="mt-2 text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="font-display text-3xl">{value}</div>
    </div>
  );
}
