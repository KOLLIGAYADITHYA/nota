import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { buildStudyPlan } from "@/lib/planner.functions";
import type { StudyPlan } from "@/lib/planner.server";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { CalendarClock, Download, Loader2, Printer, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

function planFileName(plan: StudyPlan) {
  return (plan.title || "study-plan").replace(/[^a-z0-9]+/gi, "-").replace(/^-|-$/g, "").toLowerCase();
}

function saveAsPdf(plan: StudyPlan) {
  const previous = document.title;
  document.title = planFileName(plan);
  window.print();
  window.setTimeout(() => {
    document.title = previous;
  }, 1000);
}

function planToText(plan: StudyPlan) {
  const lines: string[] = [plan.title, ""];
  if (plan.summary) lines.push(plan.summary, "");
  for (const d of plan.days) {
    lines.push(`Day ${d.day}: ${d.focus}${d.minutes ? ` (${d.minutes} min)` : ""}`);
    for (const t of d.tasks ?? []) lines.push(`  - ${t}`);
    for (const p of d.practice ?? []) lines.push(`  * Practice: ${p}`);
    if (d.checkpoint) lines.push(`  ? Check: ${d.checkpoint}`);
    lines.push("");
  }
  if (plan.importantConcepts?.length) {
    lines.push("Important concepts:", ...plan.importantConcepts.map((c) => `  - ${c}`), "");
  }
  if (plan.codingChecklist?.length) {
    lines.push("Code you must be able to write:", ...plan.codingChecklist.map((c) => `  - ${c}`), "");
  }
  if (plan.finalDayAdvice?.length) lines.push("Last 24 hours:", ...plan.finalDayAdvice.map((a) => `  - ${a}`));
  return lines.join("\n");
}

function downloadText(plan: StudyPlan) {
  const blob = new Blob([planToText(plan)], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${planFileName(plan)}.txt`;
  a.click();
  URL.revokeObjectURL(url);
}

export const Route = createFileRoute("/planner")({
  head: () => ({
    meta: [
      { title: "Exam study planner — Nota" },
      {
        name: "description",
        content:
          "Tell Nota your exam date, daily study time and level, and get a day-by-day roadmap with the most important concepts to master.",
      },
      { property: "og:title", content: "Exam study planner — Nota" },
      { property: "og:description", content: "A day-by-day roadmap built around your exam date and daily study time." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlannerPage,
});

const LEVELS = [
  { id: "beginner", label: "Beginner" },
  { id: "intermediate", label: "Know the basics" },
  { id: "advanced", label: "Advanced" },
] as const;

type Level = (typeof LEVELS)[number]["id"];

function PlannerPage() {
  return (
    <AppShell>
      <PlannerContent />
    </AppShell>
  );
}

function PlannerContent() {
  const { user } = useAuth();
  const makePlan = useServerFn(buildStudyPlan);

  const [subject, setSubject] = useState("");
  const [docId, setDocId] = useState<string | null>(null);
  const [days, setDays] = useState(7);
  const [hours, setHours] = useState(2);
  const [level, setLevel] = useState<Level>("beginner");
  const [isCoding, setIsCoding] = useState(false);
  const [busy, setBusy] = useState(false);
  const [plan, setPlan] = useState<StudyPlan | null>(null);
  const [fromNotes, setFromNotes] = useState(false);
  const [sources, setSources] = useState<{ title: string; url: string }[]>([]);

  const { data: docs } = useQuery({
    queryKey: ["documents", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("id, title")
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data;
    },
  });

  async function handlePlan() {
    if (!subject.trim() && !docId) {
      toast.error("Type the subject or unit, or pick one of your uploads.");
      return;
    }
    setBusy(true);
    setPlan(null);
    try {
      const result = await makePlan({
        data: {
          documentId: docId,
          subject: subject.trim(),
          days,
          minutesPerDay: Math.round(hours * 60),
          level,
          isCoding,
        },
      });
      setPlan(result.plan as StudyPlan);
      setFromNotes(result.fromNotes);
      setSources(result.sources);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not build that plan");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl">Study planner</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Exam in a few days? Say how many days you have, how long you can study each day and where you're
          starting from — you'll get a day-by-day roadmap and the concepts that matter most.
        </p>
      </div>

      <div className="paper space-y-5 p-5 print:hidden">
        <Input
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Subject or unit — e.g. Unit 2: AI Problem Solving, or Data Structures"
        />

        <div className="grid gap-4 sm:grid-cols-2">
          <label className="space-y-1.5">
            <span className="text-xs text-muted-foreground">Days until the exam</span>
            <Input
              type="number"
              min={1}
              max={60}
              value={days}
              onChange={(e) => setDays(Math.max(1, Math.min(60, Number(e.target.value) || 1)))}
            />
          </label>
          <label className="space-y-1.5">
            <span className="text-xs text-muted-foreground">Hours you can study each day</span>
            <Input
              type="number"
              min={0.5}
              max={12}
              step={0.5}
              value={hours}
              onChange={(e) => setHours(Math.max(0.5, Math.min(12, Number(e.target.value) || 1)))}
            />
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Your level:</span>
          {LEVELS.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => setLevel(l.id)}
              className={`rounded-full border px-2.5 py-1 text-xs ${
                level === l.id ? "border-primary bg-primary/10" : "border-border text-muted-foreground"
              }`}
            >
              {l.label}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setIsCoding((v) => !v)}
            className={`ml-2 rounded-full border px-2.5 py-1 text-xs ${
              isCoding ? "border-primary bg-primary/10" : "border-border text-muted-foreground"
            }`}
          >
            {isCoding ? "Coding subject ✓" : "This is a coding subject"}
          </button>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Base it on:</span>
          <button
            type="button"
            onClick={() => setDocId(null)}
            className={`rounded-full border px-2.5 py-1 text-xs ${
              docId === null ? "border-primary bg-primary/10" : "border-border text-muted-foreground"
            }`}
          >
            Topic only (no notes needed)
          </button>
          {(docs ?? []).map((d) => (
            <button
              key={d.id}
              type="button"
              onClick={() => setDocId(d.id)}
              className={`rounded-full border px-2.5 py-1 text-xs ${
                docId === d.id ? "border-primary bg-primary/10" : "border-border text-muted-foreground"
              }`}
            >
              {d.title}
            </button>
          ))}
        </div>

        <Button onClick={handlePlan} disabled={busy}>
          {busy ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Sparkles className="mr-2 size-4" />}
          Build my roadmap
        </Button>
      </div>

      {plan && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
            <p className="text-xs text-muted-foreground">
              {fromNotes ? "Built from your uploaded notes." : "Built from live research on this subject."}
            </p>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" size="sm" onClick={() => saveAsPdf(plan)}>
                <Printer className="mr-2 size-4" /> Save as PDF
              </Button>
              <Button variant="ghost" size="sm" onClick={() => downloadText(plan)}>
                <Download className="mr-2 size-4" /> Download notes
              </Button>
            </div>
          </div>

          <div className="paper p-6">
            <header className="border-b border-border pb-4">
              <h2 className="font-display text-3xl">{plan.title}</h2>
              {plan.summary && <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{plan.summary}</p>}
            </header>

            <div className="mt-5 space-y-4">
              {plan.days.map((d) => (
                <section key={d.day} className="rounded-lg border border-border p-4">
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <h3 className="font-display text-xl">
                      Day {d.day} — {d.focus}
                    </h3>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <CalendarClock className="size-3.5" /> ~{d.minutes} min
                    </span>
                  </div>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                    {d.tasks.map((t, i) => (
                      <li key={i}>{t}</li>
                    ))}
                  </ul>
                  {d.practice && (
                    <p className="mt-3 rounded-md bg-secondary px-3 py-2 text-xs">
                      <span className="font-medium">Practice: </span>
                      {d.practice}
                    </p>
                  )}
                  {d.checkpoint && (
                    <p className="mt-2 rounded-md border border-primary/40 bg-primary/5 px-3 py-2 text-xs">
                      <span className="font-medium">Check yourself: </span>
                      {d.checkpoint}
                    </p>
                  )}
                </section>
              ))}
            </div>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {plan.importantConcepts.length > 0 && (
                <section className="rounded-lg border border-primary/40 bg-primary/5 p-4">
                  <h3 className="font-display text-xl">Most important concepts to learn</h3>
                  <ol className="mt-2 list-decimal space-y-1 pl-5 text-sm">
                    {plan.importantConcepts.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ol>
                </section>
              )}
              {plan.codingChecklist.length > 0 && (
                <section className="rounded-lg border border-border p-4">
                  <h3 className="font-display text-xl">Code you must be able to write</h3>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                    {plan.codingChecklist.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ul>
                </section>
              )}
              {plan.finalDayAdvice.length > 0 && (
                <section className="rounded-lg border border-border p-4">
                  <h3 className="font-display text-xl">Last 24 hours</h3>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                    {plan.finalDayAdvice.map((c, i) => (
                      <li key={i}>{c}</li>
                    ))}
                  </ul>
                </section>
              )}
            </div>
          </div>
        </div>
      )}

      {sources.length > 0 && (
        <div className="paper p-5 print:hidden">
          <h2 className="font-display text-2xl">Sources</h2>
          <ul className="mt-2 space-y-1 text-sm">
            {sources.map((s) => (
              <li key={s.url}>
                <a href={s.url} target="_blank" rel="noreferrer" className="underline underline-offset-2">
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
