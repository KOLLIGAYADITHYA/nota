import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { buildRevisionSheet, explainTopic } from "@/lib/revision.functions";
import type { RevisionSheet } from "@/lib/revision.server";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { GraduationCap, Loader2, Printer, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/revise")({
  head: () => ({
    meta: [
      { title: "Revision sheets — Nota" },
      {
        name: "description",
        content:
          "Generate a printable exam revision sheet from your notes, or from any topic even when you have nothing uploaded.",
      },
      { property: "og:title", content: "Revision sheets — Nota" },
      { property: "og:description", content: "One-page exam revision sheets from your notes or any topic." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RevisePage,
});

function RevisePage() {
  return (
    <AppShell>
      <ReviseContent />
    </AppShell>
  );
}

type Source = { title: string; url: string };

function ReviseContent() {
  const { user } = useAuth();
  const makeSheet = useServerFn(buildRevisionSheet);
  const explain = useServerFn(explainTopic);

  const [topic, setTopic] = useState("");
  const [docId, setDocId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [explaining, setExplaining] = useState(false);
  const [sheet, setSheet] = useState<RevisionSheet | null>(null);
  const [sources, setSources] = useState<Source[]>([]);
  const [fromNotes, setFromNotes] = useState(false);
  const [explanation, setExplanation] = useState<string | null>(null);

  const { data: docs } = useQuery({
    queryKey: ["documents", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("id, title")
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data;
    },
  });

  async function handleSheet() {
    if (!topic.trim() && !docId) {
      toast.error("Type a topic or pick one of your uploads.");
      return;
    }
    setBusy(true);
    setSheet(null);
    try {
      const result = await makeSheet({
        data: { documentId: docId, topic: topic.trim(), useWeb: true },
      });
      setSheet(result.sheet as RevisionSheet);
      setSources(result.sources);
      setFromNotes(result.fromNotes);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not build that sheet");
    } finally {
      setBusy(false);
    }
  }

  async function handleExplain() {
    if (!topic.trim()) {
      toast.error("Type a topic to have it explained.");
      return;
    }
    setExplaining(true);
    setExplanation(null);
    try {
      const result = await explain({ data: { topic: topic.trim() } });
      setExplanation(result.explanation);
      setSources(result.sources);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not explain that topic");
    } finally {
      setExplaining(false);
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl">Revision sheets</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
          Build a printable, exam-night revision sheet from one of your uploads — or from any topic at all,
          even when you have nothing uploaded.
        </p>
      </div>

      <div className="paper space-y-4 p-5 print:hidden">
        <div className="flex flex-col gap-2 sm:flex-row">
          <Input
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Topic — e.g. Uninformed search techniques in AI"
          />
          <Button onClick={handleSheet} disabled={busy}>
            {busy ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Sparkles className="mr-2 size-4" />}
            Make revision sheet
          </Button>
          <Button variant="outline" onClick={handleExplain} disabled={explaining}>
            {explaining ? (
              <Loader2 className="mr-2 size-4 animate-spin" />
            ) : (
              <GraduationCap className="mr-2 size-4" />
            )}
            Explain this topic
          </Button>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-xs text-muted-foreground">Base it on:</span>
          <button
            type="button"
            onClick={() => setDocId(null)}
            className={`rounded-full border px-2.5 py-1 text-xs ${
              docId === null ? "border-primary bg-primary/10" : "border-border text-muted-foreground"
            }`}
          >
            Topic only (no notes needed)
          </button>
          {(docs ?? []).map((d) => (
            <button
              key={d.id}
              type="button"
              onClick={() => setDocId(d.id)}
              className={`rounded-full border px-2.5 py-1 text-xs ${
                docId === d.id ? "border-primary bg-primary/10" : "border-border text-muted-foreground"
              }`}
            >
              {d.title}
            </button>
          ))}
        </div>
      </div>

      {explanation && (
        <div className="paper p-5">
          <h2 className="font-display text-2xl">Explained</h2>
          <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed">{explanation}</p>
        </div>
      )}

      {sheet && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
            <p className="text-xs text-muted-foreground">
              {fromNotes ? "Built from your uploaded notes, topped up with the web." : "Built from live web research."}
            </p>
            <Button variant="outline" size="sm" onClick={() => window.print()}>
              <Printer className="mr-2 size-4" /> Print
            </Button>
          </div>

          <div className="paper p-6">
            <header className="border-b border-border pb-4 text-center">
              <h2 className="font-display text-3xl uppercase tracking-wide">{sheet.title}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{sheet.subtitle}</p>
            </header>
            {sheet.overview && <p className="mt-4 text-sm leading-relaxed">{sheet.overview}</p>}

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {sheet.blocks.map((b, i) => (
                <section key={i} className="rounded-lg border border-border p-4">
                  <h3 className="font-display text-xl">
                    {i + 1}. {b.heading}
                  </h3>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                    {b.points.map((p, pi) => (
                      <li key={pi}>{p}</li>
                    ))}
                  </ul>
                  {b.table && b.table.columns.length > 0 && (
                    <div className="mt-3 overflow-x-auto">
                      <table className="w-full border-collapse text-xs">
                        <thead>
                          <tr>
                            {b.table.columns.map((c, ci) => (
                              <th key={ci} className="border border-border px-2 py-1 text-left font-medium">
                                {c}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {b.table.rows.map((r, ri) => (
                            <tr key={ri}>
                              {r.map((cell, ci) => (
                                <td key={ci} className="border border-border px-2 py-1 align-top">
                                  {cell}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                  {b.memoryTrick && (
                    <p className="mt-3 rounded-md bg-secondary px-3 py-2 text-xs">
                      <span className="font-medium">Memory trick: </span>
                      {b.memoryTrick}
                    </p>
                  )}
                </section>
              ))}
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              {sheet.examFocus.length > 0 && (
                <section className="rounded-lg border border-primary/40 bg-primary/5 p-4">
                  <h3 className="font-display text-xl">Most important for exams</h3>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                    {sheet.examFocus.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                </section>
              )}
              {sheet.keyPoints.length > 0 && (
                <section className="rounded-lg border border-border p-4">
                  <h3 className="font-display text-xl">Key points to remember</h3>
                  <ul className="mt-2 list-disc space-y-1 pl-5 text-sm">
                    {sheet.keyPoints.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                </section>
              )}
            </div>
          </div>
        </div>
      )}

      {sources.length > 0 && (
        <div className="paper p-5 print:hidden">
          <h2 className="font-display text-2xl">Sources</h2>
          <ul className="mt-2 space-y-1 text-sm">
            {sources.map((s) => (
              <li key={s.url}>
                <a href={s.url} target="_blank" rel="noreferrer" className="underline underline-offset-2">
                  {s.title}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
