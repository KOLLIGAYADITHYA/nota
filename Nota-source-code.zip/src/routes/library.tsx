import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { chunkPages, extractPdfPages } from "@/lib/pdf";
import { ingestChunks } from "@/lib/study.functions";
import { useServerFn } from "@tanstack/react-start";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { FileText, Loader2, Upload } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/library")({
  head: () => ({
    meta: [
      { title: "Your library — Nota" },
      { name: "description", content: "Upload lecture notes and PDFs, then study them with cited AI answers and quizzes." },
      { property: "og:title", content: "Your library — Nota" },
      { property: "og:description", content: "All of your uploaded study material in one place." },
    ],
  }),
  component: LibraryPage,
});

function LibraryPage() {
  return (
    <AppShell>
      <LibraryContent />
    </AppShell>
  );
}

function LibraryContent() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const inputRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState<string | null>(null);
  const ingest = useServerFn(ingestChunks);

  const { data: docs, isLoading } = useQuery({
    queryKey: ["documents", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("id, title, page_count, chunk_count, status, created_at")
        .order("created_at", { ascending: false });
      if (error) throw new Error(error.message);
      return data;
    },
  });

  async function handleFile(file: File) {
    if (!user) return;
    try {
      setStatus("Reading PDF…");
      const pages = await extractPdfPages(file, (done, total) =>
        setStatus(`Reading page ${done} of ${total}…`),
      );
      const chunks = chunkPages(pages);
      if (!chunks.length) throw new Error("No selectable text found in this PDF.");

      const { data: doc, error } = await supabase
        .from("documents")
        .insert({ title: file.name.replace(/\.pdf$/i, ""), page_count: pages.length, status: "processing" })
        .select("id")
        .single();
      if (error || !doc) throw new Error(error?.message ?? "Could not save document.");

      const batchSize = 60;
      for (let i = 0; i < chunks.length; i += batchSize) {
        setStatus(`Indexing ${Math.min(i + batchSize, chunks.length)} / ${chunks.length} sections…`);
        await ingest({ data: { documentId: doc.id, chunks: chunks.slice(i, i + batchSize) } });
      }

      await supabase
        .from("documents")
        .update({ status: "ready", chunk_count: chunks.length })
        .eq("id", doc.id);

      toast.success("Document indexed and ready.");
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setStatus(null);
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl">Your library</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Upload a PDF of your notes. Nota only answers from what you upload.
          </p>
        </div>
        <div>
          <input
            ref={inputRef}
            type="file"
            accept="application/pdf"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              e.target.value = "";
              if (file) void handleFile(file);
            }}
          />
          <Button onClick={() => inputRef.current?.click()} disabled={!!status}>
            {status ? <Loader2 className="mr-2 size-4 animate-spin" /> : <Upload className="mr-2 size-4" />}
            {status ?? "Upload PDF"}
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex h-40 items-center justify-center text-muted-foreground">
          <Loader2 className="size-5 animate-spin" />
        </div>
      ) : !docs?.length ? (
        <div className="paper p-10 text-center text-muted-foreground">
          Nothing here yet. Upload your first set of notes to get started.
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {docs.map((doc) => (
            <Link
              key={doc.id}
              to="/doc/$docId"
              params={{ docId: doc.id }}
              className="paper flex flex-col gap-3 p-5 transition-colors hover:border-primary"
            >
              <FileText className="size-5 text-primary" />
              <span className="font-medium leading-snug">{doc.title}</span>
              <span className="mt-auto text-xs text-muted-foreground">
                {doc.page_count} pages · {doc.chunk_count} sections · {doc.status}
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
