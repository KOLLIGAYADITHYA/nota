import { AppShell } from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useIsAdmin } from "@/hooks/useIsAdmin";
import { getUserActivity, listUsers, setAdminRole } from "@/lib/admin.functions";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { FileText, Loader2, MessageSquare, ShieldCheck, Target, Users } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — Nota" },
      { name: "description", content: "Admin area: registered members, platform usage and access control for Nota." },
      { property: "og:title", content: "Admin — Nota" },
      { property: "og:description", content: "Manage members and review platform usage." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  return (
    <AppShell>
      <AdminContent />
    </AppShell>
  );
}

function AdminContent() {
  const { isAdmin, loading } = useIsAdmin();
  const fetchUsers = useServerFn(listUsers);
  const fetchActivity = useServerFn(getUserActivity);
  const changeRole = useServerFn(setAdminRole);

  const [search, setSearch] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);

  const usersQuery = useQuery({
    queryKey: ["admin-users"],
    enabled: isAdmin,
    queryFn: () => fetchUsers({}),
  });

  const activityQuery = useQuery({
    queryKey: ["admin-activity", openId],
    enabled: !!openId,
    queryFn: () => fetchActivity({ data: { userId: openId! } }),
  });

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center text-muted-foreground">
        <Loader2 className="size-5 animate-spin" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="paper mx-auto max-w-md p-6 text-center">
        <ShieldCheck className="mx-auto size-6 text-primary" />
        <h1 className="mt-3 font-display text-2xl">Admins only</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          This area is reserved for platform administrators.
        </p>
      </div>
    );
  }

  const data = usersQuery.data;
  const filtered = (data?.users ?? []).filter((u) =>
    `${u.email} ${u.displayName}`.toLowerCase().includes(search.trim().toLowerCase()),
  );

  async function toggleAdmin(userId: string, makeAdmin: boolean) {
    try {
      await changeRole({ data: { userId, makeAdmin } });
      toast.success(makeAdmin ? "Admin access granted" : "Admin access removed");
      usersQuery.refetch();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not change access");
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl">Admin</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Everyone registered on Nota, what they are studying, and who can administer the platform.
        </p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={Users} label="Members" value={String(data?.totals.users ?? 0)} />
        <Stat icon={FileText} label="Documents" value={String(data?.totals.documents ?? 0)} />
        <Stat icon={Target} label="Questions answered" value={String(data?.totals.questions ?? 0)} />
        <Stat icon={MessageSquare} label="Tutor messages" value={String(data?.totals.messages ?? 0)} />
      </div>

      <div className="paper p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-2xl">Registered users</h2>
          <Input
            className="max-w-xs"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or email"
          />
        </div>

        {usersQuery.isLoading ? (
          <div className="flex h-32 items-center justify-center text-muted-foreground">
            <Loader2 className="size-5 animate-spin" />
          </div>
        ) : usersQuery.isError ? (
          <p className="mt-3 text-sm text-destructive">Could not load members.</p>
        ) : filtered.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">No members match that search.</p>
        ) : (
          <div className="mt-4 overflow-x-auto">
            <table className="w-full border-collapse text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wide text-muted-foreground">
                  <th className="py-2 pr-3">Member</th>
                  <th className="py-2 pr-3">Joined</th>
                  <th className="py-2 pr-3">Docs</th>
                  <th className="py-2 pr-3">Questions</th>
                  <th className="py-2 pr-3">Accuracy</th>
                  <th className="py-2 pr-3">Access</th>
                  <th className="py-2" />
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((u) => (
                  <tr key={u.id}>
                    <td className="py-3 pr-3">
                      <p className="font-medium">{u.displayName || u.email}</p>
                      <p className="text-xs text-muted-foreground">{u.email}</p>
                    </td>
                    <td className="py-3 pr-3 text-muted-foreground">
                      {new Date(u.joinedAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 pr-3">{u.documents}</td>
                    <td className="py-3 pr-3">{u.questions}</td>
                    <td className="py-3 pr-3">{u.accuracy}%</td>
                    <td className="py-3 pr-3">
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs ${
                          u.isAdmin ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"
                        }`}
                      >
                        {u.isAdmin ? "Admin" : "Student"}
                      </span>
                    </td>
                    <td className="py-3">
                      <div className="flex justify-end gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setOpenId(openId === u.id ? null : u.id)}
                        >
                          {openId === u.id ? "Hide" : "View"}
                        </Button>
                        <Button
                          size="sm"
                          variant={u.isAdmin ? "outline" : "default"}
                          onClick={() => toggleAdmin(u.id, !u.isAdmin)}
                        >
                          {u.isAdmin ? "Remove admin" : "Make admin"}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {openId && (
        <div className="paper p-5">
          <h2 className="font-display text-2xl">Member activity</h2>
          {activityQuery.isLoading ? (
            <div className="flex h-24 items-center justify-center text-muted-foreground">
              <Loader2 className="size-5 animate-spin" />
            </div>
          ) : (
            <div className="mt-3 grid gap-5 md:grid-cols-2">
              <section>
                <h3 className="text-sm font-medium">Documents</h3>
                {(activityQuery.data?.documents ?? []).length === 0 ? (
                  <p className="mt-1 text-sm text-muted-foreground">Nothing uploaded yet.</p>
                ) : (
                  <ul className="mt-2 space-y-2 text-sm">
                    {activityQuery.data!.documents.map((d) => (
                      <li key={d.id} className="flex justify-between gap-3">
                        <span className="truncate">{d.title}</span>
                        <span className="shrink-0 text-xs text-muted-foreground">
                          {d.page_count} pages
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
              <section>
                <h3 className="text-sm font-medium">Recent quizzes</h3>
                {(activityQuery.data?.quizzes ?? []).length === 0 ? (
                  <p className="mt-1 text-sm text-muted-foreground">No quizzes yet.</p>
                ) : (
                  <ul className="mt-2 space-y-2 text-sm">
                    {activityQuery.data!.quizzes.map((q) => (
                      <li key={q.id} className="flex justify-between gap-3">
                        <span className="truncate">{q.title}</span>
                        <span className="shrink-0 text-xs text-muted-foreground">
                          {new Date(q.created_at).toLocaleDateString()}
                        </span>
                      </li>
                    ))}
                  </ul>
                )}
              </section>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function Stat({ icon: Icon, label, value }: { icon: typeof Users; label: string; value: string }) {
  return (
    <div className="paper p-5">
      <Icon className="size-4 text-primary" />
      <div className="mt-2 text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="font-display text-3xl">{value}</div>
    </div>
  );
}
