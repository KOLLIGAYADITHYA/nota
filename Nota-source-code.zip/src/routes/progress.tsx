import { AppShell } from "@/components/AppShell";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/progress")({
  head: () => ({
    meta: [
      { title: "Progress — Nota" },
      { name: "description", content: "See which topics you have mastered and which ones still need work." },
      { property: "og:title", content: "Progress — Nota" },
      { property: "og:description", content: "Topic-level mastery from your own quiz attempts." },
    ],
  }),
  component: ProgressPage,
});

function ProgressPage() {
  return (
    <AppShell>
      <ProgressContent />
    </AppShell>
  );
}

function ProgressContent() {
  const { user } = useAuth();

  const { data, isLoading } = useQuery({
    queryKey: ["attempts", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("quiz_attempts")
        .select("topic, is_correct, created_at")
        .order("created_at", { ascending: false })
        .limit(1000);
      if (error) throw new Error(error.message);
      return data;
    },
  });

  const attempts = data ?? [];
  const total = attempts.length;
  const correct = attempts.filter((a) => a.is_correct).length;

  const byTopic = new Map<string, { correct: number; total: number }>();
  for (const a of attempts) {
    const key = a.topic ?? "Uncategorised";
    const row = byTopic.get(key) ?? { correct: 0, total: 0 };
    row.total += 1;
    if (a.is_correct) row.correct += 1;
    byTopic.set(key, row);
  }
  const topics = [...byTopic.entries()].sort(
    (a, b) => a[1].correct / a[1].total - b[1].correct / b[1].total,
  );

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center text-muted-foreground">
        <Loader2 className="size-5 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-4xl">Progress</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Built from every quiz question you have answered.
        </p>
      </div>

      {total === 0 ? (
        <div className="paper p-10 text-center text-muted-foreground">
          No quiz attempts yet. Take a quiz from one of your documents.
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            <Stat label="Questions answered" value={String(total)} />
            <Stat label="Correct" value={String(correct)} />
            <Stat label="Accuracy" value={`${Math.round((correct / total) * 100)}%`} />
          </div>

          <div className="paper divide-y divide-border">
            {topics.map(([topic, row]) => {
              const pct = Math.round((row.correct / row.total) * 100);
              return (
                <div key={topic} className="flex items-center gap-4 p-4">
                  <span className="flex-1 text-sm font-medium">{topic}</span>
                  <div className="h-2 w-40 overflow-hidden rounded-full bg-secondary">
                    <div className="h-full bg-primary" style={{ width: `${pct}%` }} />
                  </div>
                  <span className="w-20 text-right text-sm text-muted-foreground">
                    {row.correct}/{row.total}
                  </span>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="paper p-5">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="font-display text-3xl">{value}</div>
    </div>
  );
}
