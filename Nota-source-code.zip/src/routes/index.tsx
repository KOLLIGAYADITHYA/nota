import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { createFileRoute, Link } from "@tanstack/react-router";
import { BookOpen, FileText, LineChart, MessageSquareQuote, Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Nota — Study from your own notes with AI" },
      {
        name: "description",
        content:
          "Upload your lecture notes and get page-cited answers, exam-style quizzes, and progress tracking built from your own material.",
      },
      { property: "og:title", content: "Nota — Study from your own notes with AI" },
      {
        property: "og:description",
        content: "Page-cited answers and quizzes generated strictly from the notes you upload.",
      },
    ],
  }),
  component: Index,
});

const FEATURES = [
  {
    icon: FileText,
    title: "Your syllabus, indexed",
    body: "Upload PDFs of lecture notes. Nota reads every page and indexes it for instant retrieval.",
  },
  {
    icon: MessageSquareQuote,
    title: "Answers with page citations",
    body: "Every answer points back to the exact pages it came from — no invented facts, no outside sources.",
  },
  {
    icon: Sparkles,
    title: "Exam-style quizzes",
    body: "Generate multiple-choice questions from any document, and retarget them at the topics you keep missing.",
  },
  {
    icon: LineChart,
    title: "Progress you can act on",
    body: "See accuracy over time and which topics still need work before the exam.",
  },
];

function Index() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <header className="mx-auto flex h-16 max-w-6xl items-center px-4">
        <Link to="/" className="flex items-center gap-2">
          <BookOpen className="size-5 text-primary" />
          <span className="font-display text-2xl leading-none">Nota</span>
        </Link>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/plan">Project plan</Link>
          </Button>
          <Button size="sm" asChild>
            <Link to={user ? "/library" : "/auth"}>{user ? "Open library" : "Sign in"}</Link>
          </Button>
        </div>
      </header>

      <main>
        <section className="mx-auto max-w-6xl px-4 pb-16 pt-12 sm:pt-20">
          <p className="text-sm uppercase tracking-[0.2em] text-muted-foreground">
            Personalised study, grounded in your material
          </p>
          <h1 className="mt-4 max-w-3xl font-display text-5xl leading-[1.05] sm:text-7xl">
            Study from <em>your</em> notes — not the internet's.
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
            Nota turns your uploaded lecture notes into a tutor that answers with page-level
            citations, drills you with exam-style questions, and tracks the topics you keep
            getting wrong.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" asChild>
              <Link to={user ? "/library" : "/auth"}>
                {user ? "Go to your library" : "Start studying free"}
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/plan">Read the project plan</Link>
            </Button>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 pb-20">
          <div className="grid gap-4 sm:grid-cols-2">
            {FEATURES.map(({ icon: Icon, title, body }) => (
              <div key={title} className="paper p-6">
                <Icon className="size-5 text-primary" />
                <h2 className="mt-4 font-display text-2xl">{title}</h2>
                <p className="mt-2 text-sm text-muted-foreground">{body}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 pb-24">
          <div className="paper flex flex-wrap items-center justify-between gap-6 p-10">
            <div>
              <h2 className="font-display text-3xl">Three steps to a better exam</h2>
              <p className="mt-2 max-w-xl text-sm text-muted-foreground">
                Upload a PDF, ask anything about it, then quiz yourself. Nota keeps score and
                focuses the next round on your weakest topics.
              </p>
            </div>
            <Button size="lg" asChild>
              <Link to={user ? "/library" : "/auth"}>Upload your first PDF</Link>
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-4 px-4 py-8 text-sm text-muted-foreground">
          <span className="font-display text-lg text-foreground">Nota</span>
          <span>Answers grounded strictly in your uploads.</span>
          <div className="ml-auto flex gap-4">
            <Link to="/library" className="hover:text-foreground">
              Library
            </Link>
            <Link to="/progress" className="hover:text-foreground">
              Progress
            </Link>
            <Link to="/plan" className="hover:text-foreground">
              Project plan
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
