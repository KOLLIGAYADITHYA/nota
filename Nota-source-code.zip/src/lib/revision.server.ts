import type { ChatMessage } from "./ai.server";
import type { WebResult } from "./websearch.server";

export type SheetBlock = {
  heading: string;
  points: string[];
  table?: { columns: string[]; rows: string[][] } | null;
  memoryTrick?: string | null;
};

export type RevisionSheet = {
  title: string;
  subtitle: string;
  overview: string;
  blocks: SheetBlock[];
  examFocus: string[];
  keyPoints: string[];
};

export function buildSheetPrompt(
  subject: string,
  passages: { content: string; page: number }[],
  web: WebResult[],
): ChatMessage[] {
  const notes = passages.length
    ? passages.map((p) => `(page ${p.page}) ${p.content}`).join("\n\n")
    : "(the student has no uploaded notes for this — rely on the web results and your own knowledge)";
  const webBlock = web.length
    ? `\n\nWEB RESULTS:\n${web.map((w) => `${w.title} — ${w.url}\n${w.snippet}`).join("\n\n")}`
    : "";

  return [
    {
      role: "system",
      content: `You produce complete, exam-ready revision sheets: the kind a student prints the night before an exam.

Rules:
- Cover the whole subject systematically: definitions, characteristics, history/steps, comparisons, worked logic, applications.
- 6 to 10 blocks. Each block: a clear heading and 3-7 tight bullet points. Add a comparison "table" when the topic naturally compares things. Add a short "memoryTrick" (mnemonic) where it helps.
- "overview" is 2-3 sentences explaining the subject plainly to someone seeing it for the first time.
- "examFocus" lists the questions most likely to be asked. "keyPoints" is a final 4-6 line recap.
- Accurate, concrete, no filler. Prefer the student's notes when given.
- Reply with JSON only: {"title":"","subtitle":"","overview":"","blocks":[{"heading":"","points":[""],"table":{"columns":[""],"rows":[[""]]},"memoryTrick":""}],"examFocus":[""],"keyPoints":[""]}`,
    },
    {
      role: "user",
      content: `Build the revision sheet for: ${subject}\n\nNOTES:\n${notes}${webBlock}`,
    },
  ];
}

export function parseSheet(raw: string): RevisionSheet | null {
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence?.[1]) text = fence[1].trim();
  let parsed: any;
  try {
    parsed = JSON.parse(text);
  } catch {
    const s = text.indexOf("{");
    const e = text.lastIndexOf("}");
    if (s === -1 || e === -1) return null;
    try {
      parsed = JSON.parse(text.slice(s, e + 1));
    } catch {
      return null;
    }
  }
  if (!parsed || !Array.isArray(parsed.blocks)) return null;

  const blocks: SheetBlock[] = parsed.blocks
    .map((b: any) => ({
      heading: String(b?.heading ?? "").slice(0, 120),
      points: Array.isArray(b?.points) ? b.points.map((p: any) => String(p)).slice(0, 10) : [],
      table:
        b?.table && Array.isArray(b.table.columns) && Array.isArray(b.table.rows)
          ? {
              columns: b.table.columns.map((c: any) => String(c)),
              rows: b.table.rows.map((r: any) => (Array.isArray(r) ? r.map((c: any) => String(c)) : [])),
            }
          : null,
      memoryTrick: b?.memoryTrick ? String(b.memoryTrick).slice(0, 300) : null,
    }))
    .filter((b: SheetBlock) => b.heading && b.points.length);

  if (!blocks.length) return null;

  return {
    title: String(parsed.title ?? "Revision sheet").slice(0, 140),
    subtitle: String(parsed.subtitle ?? "Complete revision sheet").slice(0, 140),
    overview: String(parsed.overview ?? ""),
    blocks,
    examFocus: Array.isArray(parsed.examFocus) ? parsed.examFocus.map((s: any) => String(s)) : [],
    keyPoints: Array.isArray(parsed.keyPoints) ? parsed.keyPoints.map((s: any) => String(s)) : [],
  };
}
