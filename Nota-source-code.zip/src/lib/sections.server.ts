// Heuristic section/chapter detection over a document's ordered chunks.

export type RawChunk = { content: string; page: number; chunk_index: number };

export type DocSection = {
  index: number;
  title: string;
  startPage: number;
  endPage: number;
  chunkCount: number;
  from: number; // inclusive chunk array position
  to: number; // exclusive
};

const HEADING_PATTERNS: RegExp[] = [
  /\b((?:Chapter|CHAPTER|Unit|UNIT|Module|MODULE|Lecture|Part|Section)\s+(?:\d{1,2}|[IVXLC]{1,5})\b[ .:—-]{0,3}[A-Z][^.\n]{0,70})/,
  /(?:^|\s)(\d{1,2}\.\d{0,2}\s+[A-Z][A-Za-z][^.\n]{3,70})/,
  /(?:^|\s)([A-Z][A-Z &'/-]{6,60})(?=\s)/, // ALL-CAPS heading run
];

function findHeading(text: string): string | null {
  const head = text.slice(0, 400);
  for (const re of HEADING_PATTERNS) {
    const m = head.match(re);
    const t = m?.[1]?.trim().replace(/\s+/g, " ");
    if (t && t.length >= 4 && t.length <= 80) return t;
  }
  return null;
}

/** Group ordered chunks into titled sections. Falls back to even page bands. */
export function detectSections(chunks: RawChunk[], maxSections = 12): DocSection[] {
  if (!chunks.length) return [];

  const starts: { at: number; title: string }[] = [];
  for (let i = 0; i < chunks.length; i++) {
    const title = findHeading(chunks[i]!.content);
    if (!title) continue;
    const prev = starts[starts.length - 1];
    // require some distance so we don't fragment on every capitalised phrase
    if (prev && i - prev.at < Math.max(2, Math.floor(chunks.length / (maxSections * 2)))) continue;
    starts.push({ at: i, title });
  }

  let bounds: { at: number; title: string }[];
  if (starts.length >= 2 && starts.length <= maxSections * 2) {
    bounds = starts[0]!.at === 0 ? starts : [{ at: 0, title: "Opening pages" }, ...starts];
    if (bounds.length > maxSections) {
      const stride = bounds.length / maxSections;
      bounds = Array.from({ length: maxSections }, (_, i) => bounds[Math.floor(i * stride)]!);
    }
  } else {
    const parts = Math.min(maxSections, Math.max(2, Math.ceil(chunks.length / 12)));
    const size = Math.ceil(chunks.length / parts);
    bounds = Array.from({ length: parts }, (_, i) => ({ at: i * size, title: "" }));
  }

  return bounds.map((b, i) => {
    const from = b.at;
    const to = i + 1 < bounds.length ? bounds[i + 1]!.at : chunks.length;
    const slice = chunks.slice(from, to);
    const startPage = slice[0]?.page ?? 1;
    const endPage = slice[slice.length - 1]?.page ?? startPage;
    return {
      index: i,
      title: b.title || `Pages ${startPage}–${endPage}`,
      startPage,
      endPage,
      chunkCount: slice.length,
      from,
      to,
    };
  });
}

/** Evenly sample up to `take` trimmed passages from a chunk range. */
export function samplePassages(chunks: RawChunk[], take = 12, chars = 900) {
  const n = Math.min(take, chunks.length);
  if (!n) return [];
  const stride = chunks.length / n;
  return Array.from({ length: n }, (_, i) => {
    const c = chunks[Math.floor(i * stride)]!;
    return { page: c.page, content: String(c.content).slice(0, chars) };
  });
}
