export type AgentId = "tutor" | "researcher" | "examiner" | "planner";

export const AGENTS: { id: AgentId; name: string; blurb: string; usesWeb: boolean }[] = [
  {
    id: "tutor",
    name: "Tutor",
    blurb: "Explains concepts from your notes, step by step, with page citations.",
    usesWeb: false,
  },
  {
    id: "researcher",
    name: "Researcher",
    blurb: "Goes beyond your notes and searches the web, citing sources.",
    usesWeb: true,
  },
  {
    id: "examiner",
    name: "Examiner",
    blurb: "Answers like a grader: definitions, key points, common mistakes.",
    usesWeb: false,
  },
  {
    id: "planner",
    name: "Planner",
    blurb: "Turns the material into a concrete study schedule and checklist.",
    usesWeb: false,
  },
];
