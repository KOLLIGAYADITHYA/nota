import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { buildPlanPrompt, parsePlan } from "./planner.server";

/** Builds a day-by-day exam roadmap from a topic/unit and, optionally, an upload. */
export const buildStudyPlan = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        documentId: z.string().uuid().nullish(),
        subject: z.string().max(200).default(""),
        days: z.number().int().min(1).max(60),
        minutesPerDay: z.number().int().min(15).max(720),
        level: z.enum(["beginner", "intermediate", "advanced"]).default("beginner"),
        isCoding: z.boolean().default(false),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { chatComplete } = await import("./ai.server");
    const { webSearch } = await import("./websearch.server");
    const { samplePassages } = await import("./sections.server");
    const supabase = context.supabase;

    let subject = data.subject.trim();
    let passages: { content: string; page: number }[] = [];

    if (data.documentId) {
      const { data: doc } = await supabase
        .from("documents")
        .select("title")
        .eq("id", data.documentId)
        .maybeSingle();
      const { data: chunks } = await supabase
        .from("doc_chunks")
        .select("content, page, chunk_index")
        .eq("document_id", data.documentId)
        .order("chunk_index", { ascending: true })
        .limit(800);
      if (chunks?.length) passages = samplePassages(chunks as never, 18, 800);
      if (!subject) subject = (doc as { title: string } | null)?.title ?? "My notes";
    }

    if (!subject) throw new Error("Tell me the subject or unit, or pick one of your uploads.");

    const web = passages.length ? [] : await webSearch(`${subject} syllabus important topics exam`, 5);

    const raw = await chatComplete(
      buildPlanPrompt(
        {
          subject,
          days: data.days,
          minutesPerDay: data.minutesPerDay,
          level: data.level,
          isCoding: data.isCoding,
        },
        passages,
        web,
      ),
      { jsonMode: true, temperature: 0.4 },
    );

    const plan = parsePlan(raw, data.days);
    if (!plan) throw new Error("Could not build a plan for that. Try rewording the subject.");

    return {
      plan,
      fromNotes: passages.length > 0,
      sources: web.slice(0, 5).map((w) => ({ title: w.title, url: w.url })),
    };
  });
