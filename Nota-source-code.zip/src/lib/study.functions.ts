import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { buildQuizPrompt, buildTutorPrompt, parseQuizJson } from "./study.server";
import type { AgentId, ParsedQuestion } from "./study.server";

const ChunkSchema = z.object({
  content: z.string(),
  page: z.number(),
  chunk_index: z.number(),
});

export const ingestChunks = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        documentId: z.string().uuid(),
        chunks: z.array(ChunkSchema).min(1).max(120),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { embedTexts } = await import("./ai.server");
    const vectors = await embedTexts(data.chunks.map((c) => c.content));

    const rows = data.chunks.map((c, i) => ({
      document_id: data.documentId,
      user_id: context.userId,
      content: c.content,
      page: c.page,
      chunk_index: c.chunk_index,
      embedding: JSON.stringify(vectors[i]),
    }));

    const { error } = await context.supabase.from("doc_chunks").insert(rows as never);
    if (error) throw new Error(error.message);
    return { inserted: rows.length };
  });

export const askDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        documentId: z.string().uuid(),
        question: z.string().min(2).max(2000),
        agent: z.enum(["tutor", "researcher", "examiner", "planner"]).default("tutor"),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { embedTexts, chatComplete } = await import("./ai.server");
    const { webSearch } = await import("./websearch.server");
    const supabase = context.supabase;

    const [queryVector] = await embedTexts([data.question]);
    const { data: matches, error } = await supabase.rpc("match_chunks", {
      query_embedding: JSON.stringify(queryVector) as never,
      match_count: 8,
      doc_id: data.documentId,
    });
    if (error) throw new Error(error.message);

    const passages = (matches ?? []).filter((m: any) => m.similarity > 0.15);

    const { data: history } = await supabase
      .from("messages")
      .select("role, content")
      .eq("document_id", data.documentId)
      .order("created_at", { ascending: true })
      .limit(12);

    // Researcher always searches the web; other agents only fall back to it
    // when the notes have nothing useful.
    const agent = data.agent as AgentId;
    const shouldSearch = agent === "researcher" || passages.length === 0;
    const web = shouldSearch ? await webSearch(data.question, 5) : [];

    const answer =
      passages.length || web.length
        ? await chatComplete(buildTutorPrompt(passages, history ?? [], data.question, agent, web), {
            temperature: 0.3,
          })
        : "I could not find anything about that in your notes, and the web search came back empty. Try rephrasing the question.";

    const citations = [
      ...passages.slice(0, 4).map((p: any) => ({
        page: p.page,
        snippet: String(p.content).slice(0, 220),
        similarity: Number(p.similarity.toFixed(3)),
        url: null as string | null,
        title: null as string | null,
      })),
      ...web.slice(0, 4).map((w) => ({
        page: 0,
        snippet: w.snippet.slice(0, 220),
        similarity: 0,
        url: w.url,
        title: w.title,
      })),
    ];

    await supabase.from("messages").insert([
      { document_id: data.documentId, user_id: context.userId, role: "user", content: data.question },
      {
        document_id: data.documentId,
        user_id: context.userId,
        role: "assistant",
        content: answer,
        citations: citations as never,
      },
    ] as never);

    return { answer, citations };
  });

const BATCH = 5;

async function loadChunks(supabase: any, documentId: string) {
  const { data, error } = await supabase
    .from("doc_chunks")
    .select("content, page, chunk_index")
    .eq("document_id", documentId)
    .order("chunk_index", { ascending: true })
    .limit(800);
  if (error) throw new Error(error.message);
  if (!data?.length) throw new Error("This document has no indexed text yet.");
  return data as { content: string; page: number; chunk_index: number }[];
}

/** Chapters / sections detected in the upload, for the range picker. */
export const listDocumentSections = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ documentId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { detectSections } = await import("./sections.server");
    const chunks = await loadChunks(context.supabase, data.documentId);
    return detectSections(chunks).map((s) => ({
      index: s.index,
      title: s.title,
      startPage: s.startPage,
      endPage: s.endPage,
      chunkCount: s.chunkCount,
    }));
  });

const ScopeSchema = z.object({
  documentId: z.string().uuid(),
  count: z.number().min(3).max(30).default(20),
  focusWeakTopics: z.boolean().default(false),
  sectionIndices: z.array(z.number().int().min(0)).default([]),
  pageFrom: z.number().int().min(1).nullish(),
  pageTo: z.number().int().min(1).nullish(),
});

type Scope = z.infer<typeof ScopeSchema>;

async function scopedMaterial(supabase: any, data: Scope) {
  const { detectSections, samplePassages } = await import("./sections.server");
  const all = await loadChunks(supabase, data.documentId);
  const sections = detectSections(all);

  let selected = sections;
  if (data.sectionIndices.length) {
    selected = sections.filter((s) => data.sectionIndices.includes(s.index));
  }
  let chunks = selected.flatMap((s) => all.slice(s.from, s.to));

  if (data.pageFrom || data.pageTo) {
    const lo = data.pageFrom ?? 1;
    const hi = data.pageTo ?? Number.MAX_SAFE_INTEGER;
    const ranged = chunks.filter((c) => c.page >= lo && c.page <= hi);
    if (ranged.length) {
      chunks = ranged;
      selected = selected.filter((s) => s.endPage >= lo && s.startPage <= hi);
    }
  }
  if (!chunks.length) {
    chunks = all;
    selected = sections;
  }
  return { chunks, selected, samplePassages };
}

/** Plans the quiz: creates the quiz row and returns the batches to generate. */
export const startQuiz = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => ScopeSchema.parse(input))
  .handler(async ({ data, context }) => {
    const supabase = context.supabase;
    const { data: doc } = await supabase
      .from("documents")
      .select("id, title")
      .eq("id", data.documentId)
      .maybeSingle();
    if (!doc) throw new Error("Document not found.");

    const { selected } = await scopedMaterial(supabase, data);

    const { data: quiz, error } = await supabase
      .from("quizzes")
      .insert({
        document_id: data.documentId,
        user_id: context.userId,
        title: `${(doc as { title: string }).title} — ${data.count} questions`,
      } as never)
      .select("id")
      .single();
    if (error || !quiz) throw new Error(error?.message ?? "Could not save quiz.");

    const batches = Math.ceil(data.count / BATCH);
    return {
      quizId: (quiz as { id: string }).id,
      batches: Array.from({ length: batches }, (_, b) => ({
        batchIndex: b,
        count: Math.min(BATCH, data.count - b * BATCH),
      })),
      sectionsUsed: selected.map((s) => ({
        index: s.index,
        title: s.title,
        startPage: s.startPage,
        endPage: s.endPage,
      })),
    };
  });

/** Generates and stores one batch; the client calls these in parallel and streams results in. */
export const generateQuizBatch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    ScopeSchema.extend({
      quizId: z.string().uuid(),
      batchIndex: z.number().int().min(0),
      batchCount: z.number().int().min(1).max(10),
      totalBatches: z.number().int().min(1),
    }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { chatComplete } = await import("./ai.server");
    const supabase = context.supabase;

    let weakTopics: string[] = [];
    if (data.focusWeakTopics) {
      const { data: attempts } = await supabase
        .from("quiz_attempts")
        .select("topic, is_correct")
        .eq("user_id", context.userId)
        .limit(500);
      const tally = new Map<string, { wrong: number; total: number }>();
      for (const a of attempts ?? []) {
        if (!a.topic) continue;
        const t = tally.get(a.topic) ?? { wrong: 0, total: 0 };
        t.total += 1;
        if (!a.is_correct) t.wrong += 1;
        tally.set(a.topic, t);
      }
      weakTopics = [...tally.entries()]
        .filter(([, v]) => v.wrong > 0)
        .sort((a, b) => b[1].wrong / b[1].total - a[1].wrong / a[1].total)
        .slice(0, 5)
        .map(([k]) => k);
    }

    const { chunks, samplePassages } = await scopedMaterial(supabase, data);
    const size = Math.ceil(chunks.length / data.totalBatches);
    const slice = chunks.slice(data.batchIndex * size, (data.batchIndex + 1) * size);
    const material = samplePassages(slice.length ? slice : chunks, 12);

    let questions: ParsedQuestion[] = [];
    try {
      const raw = await chatComplete(buildQuizPrompt(material, data.batchCount, weakTopics), {
        jsonMode: true,
        temperature: 0.6,
      });
      questions = parseQuizJson(raw, data.batchCount);
    } catch {
      questions = [];
    }
    if (!questions.length) return { questions: [] };

    const { data: rows, error } = await supabase
      .from("quiz_questions")
      .insert(
        questions.map((q, i) => ({
          quiz_id: data.quizId,
          user_id: context.userId,
          question: q.question,
          options: q.options as never,
          correct_index: q.correct_index,
          explanation: q.explanation,
          topic: q.topic,
          page: q.page,
          position: data.batchIndex * BATCH + i,
        })) as never,
      )
      .select("id, question, options, correct_index, explanation, topic, page, position");
    if (error) throw new Error(error.message);

    return { questions: rows ?? [] };
  });

