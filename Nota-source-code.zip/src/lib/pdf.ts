// Browser-side PDF text extraction + chunking. Runs after user interaction only.

export type PageText = { page: number; text: string };
export type Chunk = { content: string; page: number; chunk_index: number };

export async function extractPdfPages(
  file: File,
  onProgress?: (done: number, total: number) => void,
): Promise<PageText[]> {
  const pdfjs = await import("pdfjs-dist");
  const workerSrc = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")).default;
  pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;

  const buffer = await file.arrayBuffer();
  const doc = await pdfjs.getDocument({ data: buffer }).promise;
  const pages: PageText[] = [];

  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const text = content.items
      .map((item) => ("str" in item ? item.str : ""))
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();
    pages.push({ page: i, text });
    onProgress?.(i, doc.numPages);
  }
  return pages;
}

const CHUNK_CHARS = 1100;
const OVERLAP = 150;

export function chunkPages(pages: PageText[]): Chunk[] {
  const chunks: Chunk[] = [];
  let index = 0;

  for (const { page, text } of pages) {
    if (text.length < 40) continue; // skip near-empty / image-only pages
    let start = 0;
    while (start < text.length) {
      let end = Math.min(start + CHUNK_CHARS, text.length);
      if (end < text.length) {
        const boundary = text.lastIndexOf(". ", end);
        if (boundary > start + CHUNK_CHARS * 0.5) end = boundary + 1;
      }
      const content = text.slice(start, end).trim();
      if (content.length > 40) chunks.push({ content, page, chunk_index: index++ });
      if (end >= text.length) break;
      start = Math.max(end - OVERLAP, start + 1);
    }
  }
  return chunks;
}
