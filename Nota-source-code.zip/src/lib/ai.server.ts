const GATEWAY = "https://ai.gateway.lovable.dev/v1";

export const EMBEDDING_MODEL = "openai/text-embedding-3-small";
export const CHAT_MODEL = "google/gemini-3.7-flash";

function key() {
  const k = process.env["LOVABLE_API_KEY"];
  if (!k) throw new Error("AI is not configured (missing LOVABLE_API_KEY).");
  return k;
}

async function gatewayFetch(path: string, body: unknown) {
  const res = await fetch(`${GATEWAY}${path}`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "Lovable-API-Key": key(),
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    if (res.status === 429) throw new Error("AI is rate limited right now. Please retry in a moment.");
    if (res.status === 402) throw new Error("AI credits are exhausted for this workspace. Add credits to continue.");
    throw new Error(`AI request failed (${res.status}): ${text.slice(0, 300)}`);
  }
  return res.json() as Promise<any>;
}

/** Embed a batch of texts. Returns one vector per input, in order. */
export async function embedTexts(inputs: string[]): Promise<number[][]> {
  if (inputs.length === 0) return [];
  const out: number[][] = [];
  const BATCH = 64;
  for (let i = 0; i < inputs.length; i += BATCH) {
    const slice = inputs.slice(i, i + BATCH);
    const json = await gatewayFetch("/embeddings", {
      model: EMBEDDING_MODEL,
      input: slice,
    });
    const sorted = [...json.data].sort((a: any, b: any) => a.index - b.index);
    for (const d of sorted) out.push(d.embedding as number[]);
  }
  return out;
}

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

export async function chatComplete(
  messages: ChatMessage[],
  opts: { jsonMode?: boolean; temperature?: number } = {},
): Promise<string> {
  const json = await gatewayFetch("/chat/completions", {
    model: CHAT_MODEL,
    messages,
    ...(opts.temperature !== undefined ? { temperature: opts.temperature } : {}),
    ...(opts.jsonMode ? { response_format: { type: "json_object" } } : {}),
  });
  return (json.choices?.[0]?.message?.content ?? "") as string;
}
