import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { buildSheetPrompt, parseSheet } from "./revision.server";

/** Builds an exam revision sheet from an uploaded document, a topic, or both. */
export const buildRevisionSheet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        documentId: z.string().uuid().nullish(),
        topic: z.string().max(200).default(""),
        useWeb: z.boolean().default(true),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { chatComplete } = await import("./ai.server");
    const { webSearch } = await import("./websearch.server");
    const { samplePassages } = await import("./sections.server");
    const supabase = context.supabase;

    let subject = data.topic.trim();
    let passages: { content: string; page: number }[] = [];

    if (data.documentId) {
      const { data: doc } = await supabase
        .from("documents")
        .select("title")
        .eq("id", data.documentId)
        .maybeSingle();
      const { data: chunks } = await supabase
        .from("doc_chunks")
        .select("content, page, chunk_index")
        .eq("document_id", data.documentId)
        .order("chunk_index", { ascending: true })
        .limit(800);
      if (chunks?.length) passages = samplePassages(chunks as never, 22, 900);
      if (!subject) subject = (doc as { title: string } | null)?.title ?? "My notes";
    }

    if (!subject) throw new Error("Give a topic, or pick one of your uploaded documents.");

    const web = data.useWeb || !passages.length ? await webSearch(`${subject} exam revision notes`, 6) : [];

    const raw = await chatComplete(buildSheetPrompt(subject, passages, web), {
      jsonMode: true,
      temperature: 0.4,
    });
    const sheet = parseSheet(raw);
    if (!sheet) throw new Error("Could not build a revision sheet for that. Try rewording the topic.");

    return {
      sheet,
      sources: web.slice(0, 5).map((w) => ({ title: w.title, url: w.url })),
      fromNotes: passages.length > 0,
    };
  });

/** Explains any topic, with or without uploaded notes. */
export const explainTopic = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ topic: z.string().min(2).max(300) }).parse(input),
  )
  .handler(async ({ data }) => {
    const { chatComplete } = await import("./ai.server");
    const { webSearch } = await import("./websearch.server");

    const web = await webSearch(data.topic, 5);
    const webBlock = web.length
      ? `\n\nWEB RESULTS:\n${web.map((w) => `${w.title} — ${w.url}\n${w.snippet}`).join("\n\n")}`
      : "";

    const explanation = await chatComplete(
      [
        {
          role: "system",
          content: `You are a patient tutor. Explain the requested topic to a motivated student who has no notes on it.
Structure: a plain-language definition, why it matters, the core ideas broken down, a worked example, common mistakes, and a 3-line recap.
Use short markdown headings and bullets. Cite web sources inline as ([title](url)) when you use them.${webBlock}`,
        },
        { role: "user", content: data.topic },
      ],
      { temperature: 0.3 },
    );

    return { explanation, sources: web.map((w) => ({ title: w.title, url: w.url })) };
  });
