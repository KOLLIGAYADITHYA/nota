import type { ChatMessage } from "./ai.server";
import type { WebResult } from "./websearch.server";

export type StudyDay = {
  day: number;
  date?: string | null;
  focus: string;
  tasks: string[];
  practice?: string | null;
  checkpoint?: string | null;
  minutes: number;
};

export type StudyPlan = {
  title: string;
  summary: string;
  days: StudyDay[];
  importantConcepts: string[];
  codingChecklist: string[];
  finalDayAdvice: string[];
};

export type PlanInput = {
  subject: string;
  days: number;
  minutesPerDay: number;
  level: "beginner" | "intermediate" | "advanced";
  isCoding: boolean;
};

export function buildPlanPrompt(
  input: PlanInput,
  passages: { content: string; page: number }[],
  web: WebResult[],
): ChatMessage[] {
  const notes = passages.length
    ? passages.map((p) => `(page ${p.page}) ${p.content}`).join("\n\n")
    : "(no uploaded notes — rely on the web results and your own knowledge)";
  const webBlock = web.length
    ? `\n\nWEB RESULTS:\n${web.map((w) => `${w.title} — ${w.url}\n${w.snippet}`).join("\n\n")}`
    : "";

  const coding = input.isCoding
    ? `This is a coding/programming subject. Every day must include hands-on practice: what to implement from scratch, how many problems to solve, and which patterns to drill. Fill "codingChecklist" with the exact programs/algorithms the student must be able to write from memory before the exam.`
    : `This is a theory subject. Leave "codingChecklist" as an empty array. Use recall drills, past-paper questions and diagrams as practice instead.`;

  const level = {
    beginner: "The student is a beginner: start from fundamentals, define terms, go slower and repeat basics before advanced parts.",
    intermediate: "The student knows the basics: move quickly through fundamentals and spend most time on applications and problem solving.",
    advanced: "The student is advanced: skip basics, focus on hard problems, edge cases, comparisons and exam-level depth.",
  }[input.level];

  return [
    {
      role: "system",
      content: `You build realistic day-by-day exam preparation roadmaps.

Rules:
- Produce EXACTLY ${input.days} day objects, numbered 1..${input.days}, ending with revision + mock test on the last day.
- Each day fits in about ${input.minutesPerDay} minutes of study. Set "minutes" close to that and never plan more than fits.
- ${level}
- ${coding}
- Each day: a clear "focus", 3-6 concrete "tasks" (what to read/watch/do), a "practice" line and a "checkpoint" (a self-test that proves the day worked).
- "importantConcepts" is the final list of the highest-value concepts to master, ordered by exam importance.
- "finalDayAdvice" is 3-5 lines for the last 24 hours before the exam.
- Concrete and specific to the subject. No filler.
- Reply with JSON only: {"title":"","summary":"","days":[{"day":1,"focus":"","tasks":[""],"practice":"","checkpoint":"","minutes":60}],"importantConcepts":[""],"codingChecklist":[""],"finalDayAdvice":[""]}`,
    },
    {
      role: "user",
      content: `Subject/unit: ${input.subject}
Days until the exam: ${input.days}
Study time available per day: ${input.minutesPerDay} minutes
Level: ${input.level}
Coding subject: ${input.isCoding ? "yes" : "no"}

NOTES:
${notes}${webBlock}`,
    },
  ];
}

export function parsePlan(raw: string, expectedDays: number): StudyPlan | null {
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence?.[1]) text = fence[1].trim();
  let parsed: any;
  try {
    parsed = JSON.parse(text);
  } catch {
    const s = text.indexOf("{");
    const e = text.lastIndexOf("}");
    if (s === -1 || e === -1) return null;
    try {
      parsed = JSON.parse(text.slice(s, e + 1));
    } catch {
      return null;
    }
  }
  if (!parsed || !Array.isArray(parsed.days)) return null;

  const strings = (v: unknown, max = 20): string[] =>
    Array.isArray(v) ? v.map((x: any) => String(x)).filter(Boolean).slice(0, max) : [];

  const days: StudyDay[] = parsed.days
    .map((d: any, i: number) => ({
      day: Number.isFinite(Number(d?.day)) ? Number(d.day) : i + 1,
      focus: String(d?.focus ?? "").slice(0, 160),
      tasks: strings(d?.tasks, 10),
      practice: d?.practice ? String(d.practice).slice(0, 400) : null,
      checkpoint: d?.checkpoint ? String(d.checkpoint).slice(0, 400) : null,
      minutes: Number.isFinite(Number(d?.minutes)) ? Number(d.minutes) : 60,
    }))
    .filter((d: StudyDay) => d.focus && d.tasks.length)
    .slice(0, expectedDays);

  if (!days.length) return null;

  return {
    title: String(parsed.title ?? "Study roadmap").slice(0, 140),
    summary: String(parsed.summary ?? ""),
    days,
    importantConcepts: strings(parsed.importantConcepts, 25),
    codingChecklist: strings(parsed.codingChecklist, 25),
    finalDayAdvice: strings(parsed.finalDayAdvice, 8),
  };
}
