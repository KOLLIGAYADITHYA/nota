import type { AgentId } from "./agents";
import type { ChatMessage } from "./ai.server";
import type { WebResult } from "./websearch.server";

type Passage = { content: string; page: number; similarity?: number };

export type { AgentId };

const PERSONAS: Record<AgentId, string> = {
  tutor: `You are the Tutor agent: patient, plain-spoken, and thorough.
Explain the idea clearly first in one or two sentences, then unpack it: definitions, why it matters, a worked example, and a common misconception. Assume a motivated undergraduate.`,
  researcher: `You are the Researcher agent. You combine the student's own notes with fresh material found on the web.
Explain thoroughly, mark clearly which parts came from the notes (cite pages) and which came from the web (cite the source title and link). Flag disagreements between the two.`,
  examiner: `You are the Examiner agent. Answer the way a strict grader would mark it: the exact definition, the key points that earn marks, a worked example, and the mistakes students usually make.`,
  planner: `You are the Planner agent. Turn the material into an actionable study plan: what to study, in what order, with time estimates and a self-check for each step.`,
};

export function buildTutorPrompt(
  passages: Passage[],
  history: { role: string; content: string }[],
  question: string,
  agent: AgentId = "tutor",
  web: WebResult[] = [],
): ChatMessage[] {
  const notes = passages.length
    ? passages.map((p, i) => `[[Note ${i + 1} — page ${p.page}]]\n${p.content}`).join("\n\n")
    : "(no matching passages in the student's uploaded material)";

  const webBlock = web.length
    ? `\n\nWEB RESULTS (live search):\n${web
        .map((w, i) => `[[Web ${i + 1}]] ${w.title} — ${w.url}\n${w.snippet}`)
        .join("\n\n")}`
    : "";

  const sourcing = web.length
    ? `- Prefer the student's notes. Use the web results to fill gaps, add context, or give extra examples.
- Cite notes inline like (p. 12) and web sources like ([title](url)).
- Never state a fact that is in neither the notes nor the web results.`
    : `- Answer ONLY from the NOTES below. If they do not cover it, say so plainly and suggest what to ask instead — or tell the student to switch to the Researcher agent to search the web.
- Cite pages inline like (p. 12) whenever you state something from a note.`;

  const system = `${PERSONAS[agent]}

Hard rules:
${sourcing}
- Structure the answer with short markdown headings or bullets when it helps. Be clear and complete, not terse to the point of being useless.
- No filler, no restating the question.

NOTES:
${notes}${webBlock}`;

  const priorTurns: ChatMessage[] = history
    .slice(-6)
    .filter((m) => m.role === "user" || m.role === "assistant")
    .map((m) => ({ role: m.role as "user" | "assistant", content: m.content }));

  return [{ role: "system", content: system }, ...priorTurns, { role: "user", content: question }];
}

export function buildQuizPrompt(
  passages: Passage[],
  count: number,
  weakTopics: string[],
  avoidQuestions: string[] = [],
): ChatMessage[] {
  const context = passages.map((p) => `(page ${p.page}) ${p.content}`).join("\n\n");
  const focus = weakTopics.length
    ? `\nThe student has previously answered these topics incorrectly, so weight questions toward them: ${weakTopics.join(", ")}.`
    : "";
  const avoid = avoidQuestions.length
    ? `\n\nDo NOT repeat or paraphrase any of these already-written questions:\n${avoidQuestions
        .map((q) => `- ${q}`)
        .join("\n")}`
    : "";

  return [
    {
      role: "system",
      content: `You write exam-quality multiple-choice questions from a student's own study material.

Rules:
- Every question must be answerable from the material given. No outside facts.
- Exactly 4 options. Exactly one correct. Distractors must be plausible, not silly.
- Test understanding, not trivia about wording.
- Spread the questions across the whole material, not just the first pages.
- "topic" is a short 1-4 word concept label. "page" is the page the answer comes from.
- You MUST return exactly the requested number of questions.
- Reply with JSON only, shaped: {"questions":[{"question":"","options":["","","",""],"correct_index":0,"explanation":"","topic":"","page":1}]}`,
    },
    {
      role: "user",
      content: `Write exactly ${count} questions from this material.${focus}${avoid}\n\nMATERIAL:\n${context}`,
    },
  ];
}

export type ParsedQuestion = {
  question: string;
  options: string[];
  correct_index: number;
  explanation: string;
  topic: string;
  page: number;
};

export function parseQuizJson(raw: string, count: number): ParsedQuestion[] {
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence?.[1]) text = fence[1].trim();

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    if (start === -1 || end === -1) return [];
    try {
      parsed = JSON.parse(text.slice(start, end + 1));
    } catch {
      return [];
    }
  }

  const list = (parsed as { questions?: unknown[] })?.questions;
  if (!Array.isArray(list)) return [];

  const out: ParsedQuestion[] = [];
  for (const item of list) {
    const q = item as Record<string, unknown>;
    const question = q["question"];
    const rawOptions = q["options"];
    const explanation = q["explanation"];
    const topic = q["topic"];
    const options = Array.isArray(rawOptions) ? rawOptions.map(String) : [];
    const correct = Number(q["correct_index"]);
    if (typeof question !== "string" || options.length !== 4) continue;
    if (!Number.isInteger(correct) || correct < 0 || correct > 3) continue;
    out.push({
      question,
      options,
      correct_index: correct,
      explanation: typeof explanation === "string" ? explanation : "",
      topic: typeof topic === "string" && topic ? topic.slice(0, 60) : "General",
      page: Number.isFinite(Number(q["page"])) ? Number(q["page"]) : 1,
    });
    if (out.length >= count) break;
  }
  return out;
}
