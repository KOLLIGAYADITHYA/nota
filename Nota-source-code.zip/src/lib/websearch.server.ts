export type WebResult = { title: string; url: string; snippet: string };

const GATEWAY = "https://ai.gateway.lovable.dev/v1/chat/completions";
const SEARCH_MODEL = "google/gemini-3.7-flash";

function parseJson(raw: string): any {
  let text = raw.trim();
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence?.[1]) text = fence[1].trim();
  try {
    return JSON.parse(text);
  } catch {
    const s = text.indexOf("{");
    const e = text.lastIndexOf("}");
    if (s === -1 || e === -1) return null;
    try {
      return JSON.parse(text.slice(s, e + 1));
    } catch {
      return null;
    }
  }
}

/**
 * Live web search through Lovable AI's grounded search.
 * Returns [] on any failure so callers can fall back to notes-only answers.
 */
export async function webSearch(query: string, limit = 5): Promise<WebResult[]> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) {
    console.error("[webSearch] LOVABLE_API_KEY is not configured");
    return [];
  }

  try {
    const res = await fetch(GATEWAY, {
      method: "POST",
      headers: { "content-type": "application/json", "Lovable-API-Key": apiKey },
      body: JSON.stringify({
        model: SEARCH_MODEL,
        tools: [{ type: "google_search" }],
        messages: [
          {
            role: "system",
            content:
              "You are a search tool. Always use web search, then report only pages the search actually returned. Never invent a URL. Reply with JSON only.",
          },
          {
            role: "user",
            content: `Search the web for: ${query}\n\nReturn up to ${limit} of the most useful, study-friendly pages as JSON: {"results":[{"title":"","url":"","snippet":"a 1-3 sentence factual summary of what that page says about the query"}]}`,
          },
        ],
      }),
    });

    if (!res.ok) {
      console.error(`[webSearch] gateway ${res.status}: ${(await res.text().catch(() => "")).slice(0, 200)}`);
      return [];
    }

    const json: any = await res.json();
    const content = json?.choices?.[0]?.message?.content ?? "";
    const parsed = parseJson(String(content));
    const rows = Array.isArray(parsed?.results) ? parsed.results : [];

    const out: WebResult[] = [];
    for (const r of rows) {
      const url = String(r?.url ?? "").trim();
      const title = String(r?.title ?? "").trim();
      if (!title || !/^https?:\/\//i.test(url)) continue;
      out.push({ title, url, snippet: String(r?.snippet ?? "").slice(0, 600) });
      if (out.length >= limit) break;
    }
    return out;
  } catch (err) {
    console.error("[webSearch] failed", err);
    return [];
  }
}
