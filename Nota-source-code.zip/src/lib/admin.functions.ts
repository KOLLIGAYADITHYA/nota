import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

/** Throws unless the caller holds the admin role. */
async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error || !data) throw new Error("Forbidden: admin access only");
}

export const getMyRole = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    return { isAdmin: Boolean(data) };
  });

/** All registered users plus their activity counts. Admin only. */
export const listUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [profiles, roles, docs, attempts, messages] = await Promise.all([
      supabaseAdmin.from("profiles").select("id, email, display_name, created_at"),
      supabaseAdmin.from("user_roles").select("user_id, role"),
      supabaseAdmin.from("documents").select("user_id"),
      supabaseAdmin.from("quiz_attempts").select("user_id, is_correct"),
      supabaseAdmin.from("messages").select("user_id"),
    ]);

    const count = (rows: { user_id: string }[] | null, id: string) =>
      (rows ?? []).filter((r) => r.user_id === id).length;

    const users = (profiles.data ?? []).map((p) => {
      const mine = (attempts.data ?? []).filter((a) => a.user_id === p.id);
      const correct = mine.filter((a) => a.is_correct).length;
      return {
        id: p.id,
        email: p.email ?? "",
        displayName: p.display_name ?? "",
        joinedAt: p.created_at,
        isAdmin: (roles.data ?? []).some((r) => r.user_id === p.id && r.role === "admin"),
        documents: count(docs.data as never, p.id),
        messages: count(messages.data as never, p.id),
        questions: mine.length,
        accuracy: mine.length ? Math.round((correct / mine.length) * 100) : 0,
      };
    });

    users.sort((a, b) => (a.joinedAt < b.joinedAt ? 1 : -1));

    return {
      users,
      totals: {
        users: users.length,
        documents: (docs.data ?? []).length,
        questions: (attempts.data ?? []).length,
        messages: (messages.data ?? []).length,
      },
    };
  });

/** One user's documents and recent quiz activity. Admin only. */
export const getUserActivity = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ userId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const [docs, attempts, quizzes] = await Promise.all([
      supabaseAdmin
        .from("documents")
        .select("id, title, page_count, chunk_count, created_at")
        .eq("user_id", data.userId)
        .order("created_at", { ascending: false })
        .limit(50),
      supabaseAdmin
        .from("quiz_attempts")
        .select("topic, is_correct, created_at")
        .eq("user_id", data.userId)
        .order("created_at", { ascending: false })
        .limit(300),
      supabaseAdmin
        .from("quizzes")
        .select("id, title, created_at")
        .eq("user_id", data.userId)
        .order("created_at", { ascending: false })
        .limit(25),
    ]);

    return {
      documents: docs.data ?? [],
      quizzes: quizzes.data ?? [],
      attempts: attempts.data ?? [],
    };
  });

/** Grant or remove the admin role for another account. Admin only. */
export const setAdminRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ userId: z.string().uuid(), makeAdmin: z.boolean() }).parse(input),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    if (data.userId === context.userId && !data.makeAdmin) {
      throw new Error("You cannot remove your own admin access.");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    if (data.makeAdmin) {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .upsert({ user_id: data.userId, role: "admin" }, { onConflict: "user_id,role" });
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", data.userId)
        .eq("role", "admin");
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });
