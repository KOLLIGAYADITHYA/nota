# Nota roadmap

- [x] Quizzes: 10/20/30 questions (batched generation so counts are actually met)
- [x] RAG + live web search fallback (Researcher agent)
- [x] AI study agents: Tutor, Researcher, Examiner, Planner
- [x] Dashboard with documents, accuracy, weak topics, agent list
- [x] Voice input (speech-to-text) and hands-free text-to-speech study mode
- [x] Quiz from chosen chapters / page ranges, with detected sections shown
- [x] Live quiz progress + questions appearing as they are written
- [x] Revision sheet generator (exam-style summary sheet from a document or a topic)
- [x] Topic-only study: search any topic and get a full explanation without uploading notes
- [ ] Multi-language answers
- [ ] Spaced-repetition study plan generation
